from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
INSTANCE_DIR = BASE_DIR / "instance"
INSTANCE_DIR.mkdir(parents=True, exist_ok=True)

class Config:
    SECRET_KEY = "tea-hotel-management-secret-key"
    SQLALCHEMY_DATABASE_URI = "sqlite:///" + str(INSTANCE_DIR / "tea_hotel_management.db")
    SQLALCHEMY_TRACK_MODIFICATIONS = False
