# Graduate Tea — Hotel Management
T.Y. B.Sc. Computer Science self-project — Armaan Deshmukh.

Frontend: HTML/CSS/JavaScript + Jinja2. Backend: Python Flask. Database: SQLite. Analytics: SQL aggregation and dashboard calculations.

Features: Login/Registration, demo data, dashboard, POS billing with thermal receipt printing, inventory tracking, operational expenses, sales reports, CSV export, live category filters, search and responsive UI. This college version focuses on fast data capture + analytics and does not require external APIs or cloud services.

Demo login:
- Admin: admin@graduatetea.local / admin123
- Cashier: cashier@graduatetea.local / cashier123

Windows:
```powershell
py -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
python run.py
```
Then open http://127.0.0.1:5000
