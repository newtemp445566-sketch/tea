from datetime import datetime, date
from app import db


class User(db.Model):
    __tablename__ = 'users'

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(150), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)

    def __repr__(self):
        return f"<User {self.name} ({self.email})>"


class MenuItem(db.Model):
    __tablename__ = 'menu_items'

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    category = db.Column(db.String(60), nullable=False)
    price = db.Column(db.Float, nullable=False)
    cost = db.Column(db.Float, default=0.0)
    stock_qty = db.Column(db.Float, default=0.0)
    low_stock = db.Column(db.Float, default=10.0)
    active = db.Column(db.Boolean, default=True)

    def __repr__(self):
        return f"<MenuItem {self.name} - ₹{self.price}>"


class Sale(db.Model):
    __tablename__ = 'sales'

    id = db.Column(db.Integer, primary_key=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    total = db.Column(db.Float, default=0.0)
    payment_mode = db.Column(db.String(30), default='Cash')
    order_type = db.Column(db.String(30), default='Takeaway')

    items = db.relationship('SaleItem', backref='sale', cascade='all, delete-orphan', lazy=True)

    def __repr__(self):
        return f"<Sale #{self.id} - ₹{self.total}>"


class SaleItem(db.Model):
    __tablename__ = 'sale_items'

    id = db.Column(db.Integer, primary_key=True)
    sale_id = db.Column(db.Integer, db.ForeignKey('sales.id'), nullable=False)
    menu_item_id = db.Column(db.Integer, db.ForeignKey('menu_items.id'), nullable=False)
    quantity = db.Column(db.Float, default=1.0)
    unit_price = db.Column(db.Float, nullable=False)

    menu_item = db.relationship('MenuItem', lazy=True)

    def __repr__(self):
        return f"<SaleItem Sale #{self.sale_id} - Item #{self.menu_item_id} x {self.quantity}>"


class Ingredient(db.Model):
    __tablename__ = 'ingredients'

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    unit = db.Column(db.String(30), nullable=False)
    quantity = db.Column(db.Float, default=0.0)
    low_stock = db.Column(db.Float, default=5.0)

    def __repr__(self):
        return f"<Ingredient {self.name} ({self.quantity} {self.unit})>"


class Expense(db.Model):
    __tablename__ = 'expenses'

    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(120), nullable=False)
    category = db.Column(db.String(60), nullable=False)
    amount = db.Column(db.Float, nullable=False)
    expense_date = db.Column(db.Date, default=date.today)

    def __repr__(self):
        return f"<Expense {self.title} - ₹{self.amount}>"
