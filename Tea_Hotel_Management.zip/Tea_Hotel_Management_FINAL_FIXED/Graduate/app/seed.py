from werkzeug.security import generate_password_hash
from datetime import datetime, timedelta, date
import random
from app import db
from app.models import User, MenuItem, Ingredient, Expense, Sale, SaleItem

def seed(force=False):
    if not force and User.query.first():
        return

    if force:
        # Clear existing tables for fresh demo data
        SaleItem.query.delete()
        Sale.query.delete()
        Expense.query.delete()
        Ingredient.query.delete()
        MenuItem.query.delete()
        User.query.delete()
        db.session.commit()

    # 1. User Accounts
    users = [
        User(
            name='Admin Manager',
            email='admin@graduatetea.local',
            password_hash=generate_password_hash('admin123')
        ),
        User(
            name='Counter Cashier',
            email='cashier@graduatetea.local',
            password_hash=generate_password_hash('cashier123')
        ),
        User(
            name='Admin',
            email='admin@chaitrack.local',
            password_hash=generate_password_hash('admin123')
        )
    ]
    db.session.add_all(users)

    # 2. Comprehensive Menu Items
    menu_items = [
        # Tea & Beverages
        MenuItem(name='Special Masala Chai', category='Tea & Beverages', price=15.0, cost=5.0, stock_qty=150.0, low_stock=25.0, active=True),
        MenuItem(name='Ginger Elaichi Tea', category='Tea & Beverages', price=20.0, cost=6.0, stock_qty=120.0, low_stock=20.0, active=True),
        MenuItem(name='Filter Coffee', category='Tea & Beverages', price=25.0, cost=8.0, stock_qty=85.0, low_stock=15.0, active=True),
        MenuItem(name='Kulhad Chai', category='Tea & Beverages', price=25.0, cost=7.0, stock_qty=75.0, low_stock=15.0, active=True),
        MenuItem(name='Lemon Green Tea', category='Tea & Beverages', price=20.0, cost=5.0, stock_qty=60.0, low_stock=15.0, active=True),
        MenuItem(name='Kashmiri Kahwa', category='Tea & Beverages', price=40.0, cost=14.0, stock_qty=40.0, low_stock=10.0, active=True),
        MenuItem(name='Cold Coffee Shake', category='Tea & Beverages', price=60.0, cost=22.0, stock_qty=35.0, low_stock=8.0, active=True),
        
        # Snacks & Bakery
        MenuItem(name='Bun Maska', category='Snacks & Bakery', price=30.0, cost=12.0, stock_qty=50.0, low_stock=10.0, active=True),
        MenuItem(name='Bun Maska Jam', category='Snacks & Bakery', price=35.0, cost=14.0, stock_qty=35.0, low_stock=10.0, active=True),
        MenuItem(name='Vada Pav', category='Snacks & Bakery', price=20.0, cost=8.0, stock_qty=65.0, low_stock=15.0, active=True),
        MenuItem(name='Samosa (2 pcs)', category='Snacks & Bakery', price=30.0, cost=12.0, stock_qty=45.0, low_stock=12.0, active=True),
        MenuItem(name='Cheese Grill Sandwich', category='Snacks & Bakery', price=70.0, cost=28.0, stock_qty=28.0, low_stock=8.0, active=True),
        MenuItem(name='Osmania Biscuits (4 pcs)', category='Snacks & Bakery', price=20.0, cost=7.0, stock_qty=95.0, low_stock=20.0, active=True),
        MenuItem(name='Cream Roll (2 pcs)', category='Snacks & Bakery', price=20.0, cost=7.0, stock_qty=40.0, low_stock=10.0, active=True),

        # Breakfast
        MenuItem(name='Kanda Poha', category='Breakfast', price=35.0, cost=12.0, stock_qty=40.0, low_stock=10.0, active=True),
        MenuItem(name='Rava Upma', category='Breakfast', price=35.0, cost=12.0, stock_qty=30.0, low_stock=8.0, active=True),
        MenuItem(name='Idli Sambar (2 pcs)', category='Breakfast', price=40.0, cost=14.0, stock_qty=35.0, low_stock=8.0, active=True),
        MenuItem(name='Medu Vada Sambar (2 pcs)', category='Breakfast', price=45.0, cost=16.0, stock_qty=25.0, low_stock=8.0, active=True),
        MenuItem(name='Misal Pav with 2 Pav', category='Breakfast', price=65.0, cost=24.0, stock_qty=22.0, low_stock=5.0, active=True),
    ]
    db.session.add_all(menu_items)
    db.session.flush()

    # 3. Ingredients & Raw Stock
    ingredients = [
        Ingredient(name='Assam CTC Tea Leaves', unit='kg', quantity=14.5, low_stock=3.0),
        Ingredient(name='Fresh Whole Milk', unit='litres', quantity=38.0, low_stock=8.0),
        Ingredient(name='Sulfurless Pure Sugar', unit='kg', quantity=25.0, low_stock=5.0),
        Ingredient(name='Cardamom, Ginger & Spices', unit='kg', quantity=3.5, low_stock=0.8),
        Ingredient(name='Filter Coffee Powder (80:20)', unit='kg', quantity=6.0, low_stock=1.5),
        Ingredient(name='Fresh Bakery Pav & Buns', unit='packs', quantity=50.0, low_stock=15.0),
        Ingredient(name='Amul Salted Butter', unit='kg', quantity=7.5, low_stock=2.0),
        Ingredient(name='Poha / Flattened Rice', unit='kg', quantity=12.0, low_stock=3.0),
        Ingredient(name='Fine Rava / Semolina', unit='kg', quantity=10.0, low_stock=2.5),
        Ingredient(name='Potatoes & Onions', unit='kg', quantity=30.0, low_stock=6.0),
        Ingredient(name='Refined Cooking Oil', unit='litres', quantity=18.0, low_stock=4.0),
        Ingredient(name='Eco Paper Cups (150ml)', unit='packs', quantity=24.0, low_stock=5.0),
    ]
    db.session.add_all(ingredients)

    # 4. Realistic Expenses
    today = date.today()
    expenses = [
        Expense(title='Daily Whole Milk Supply (40L)', category='Dairy', amount=1400.0, expense_date=today),
        Expense(title='Fresh Pav & Bun Delivery', category='Raw Materials', amount=580.0, expense_date=today),
        Expense(title='Vegetables & Lemon Supply', category='Raw Materials', amount=420.0, expense_date=today),
        Expense(title='Commercial 19kg LPG Cylinder', category='Utilities', amount=1750.0, expense_date=today - timedelta(days=2)),
        Expense(title='Eco Disposable Cups & Napkins', category='Supplies', amount=750.0, expense_date=today - timedelta(days=3)),
        Expense(title='Monthly Electricity Bill', category='Utilities', amount=3200.0, expense_date=today - timedelta(days=5)),
        Expense(title='Shop Cleaning & Detergents', category='Maintenance', amount=380.0, expense_date=today - timedelta(days=6)),
        Expense(title='Weekly Kitchen Helper Wages', category='Wages', amount=3500.0, expense_date=today - timedelta(days=7)),
    ]
    db.session.add_all(expenses)

    # 5. Historical & Recent Sales (Realistic simulated orders across recent days)
    random.seed(42)
    order_types = ['Dine-in', 'Takeaway', 'Parcel']
    payment_modes = ['Cash', 'UPI', 'Card', 'UPI']
    
    # Pre-defined realistic combos
    combos = [
        [(0, 2), (7, 1)],         # 2 Masala Chai + 1 Bun Maska
        [(0, 3), (9, 2)],         # 3 Masala Chai + 2 Vada Pav
        [(1, 2), (10, 1)],        # 2 Ginger Tea + 1 Samosa (2 pcs)
        [(2, 2), (12, 1)],        # 2 Filter Coffee + 1 Osmania Biscuits
        [(0, 4), (14, 2)],        # 4 Masala Chai + 2 Kanda Poha
        [(3, 2), (7, 2)],         # 2 Kulhad Chai + 2 Bun Maska
        [(1, 1), (18, 1)],        # 1 Ginger Tea + 1 Misal Pav
        [(6, 2), (11, 1)],        # 2 Cold Coffee + 1 Cheese Grill Sandwich
        [(2, 1), (16, 1)],        # 1 Filter Coffee + 1 Idli Sambar
        [(0, 5)],                 # 5 Masala Chai (Office group order)
        [(0, 2), (8, 1), (13, 1)],# 2 Chai + Bun Maska Jam + Cream Roll
        [(4, 2), (15, 1)],        # 2 Lemon Green Tea + 1 Upma
        [(0, 2), (17, 1)],        # 2 Chai + Medu Vada
        [(1, 3), (9, 3)],         # 3 Ginger Tea + 3 Vada Pav
        [(2, 2), (10, 2)],        # 2 Coffee + 2 Samosa
    ]

    now = datetime.utcnow()
    # Generate 35 realistic sales distributed over the last 6 days
    for i in range(35):
        days_ago = (35 - i) // 6
        hours_ago = (35 - i) % 6 * 2 + random.randint(0, 2)
        minutes_ago = random.randint(5, 55)
        sale_time = now - timedelta(days=days_ago, hours=hours_ago, minutes=minutes_ago)
        
        pay_mode = random.choice(payment_modes)
        ord_type = random.choice(order_types)
        
        sale = Sale(created_at=sale_time, payment_mode=pay_mode, order_type=ord_type)
        combo = random.choice(combos)
        total = 0.0
        
        for item_idx, qty in combo:
            menu_item = menu_items[item_idx]
            sale.items.append(SaleItem(
                menu_item_id=menu_item.id,
                quantity=float(qty),
                unit_price=menu_item.price
            ))
            total += menu_item.price * qty
            # Deduct from stock simulation
            menu_item.stock_qty = max(5.0, menu_item.stock_qty - (qty * 0.4))
            
        sale.total = total
        db.session.add(sale)

    db.session.commit()
