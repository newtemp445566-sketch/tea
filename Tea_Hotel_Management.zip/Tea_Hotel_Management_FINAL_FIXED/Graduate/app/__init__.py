from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from pathlib import Path

db = SQLAlchemy()

def create_app():
    base_dir = Path(__file__).resolve().parent.parent
    instance_dir = base_dir / "instance"
    instance_dir.mkdir(parents=True, exist_ok=True)

    app = Flask(__name__)
    app.config.from_object("config.Config")

    db.init_app(app)

    from app.routes import auth, main, pos, inventory, expenses, reports
    app.register_blueprint(auth.bp)
    app.register_blueprint(main.bp)
    app.register_blueprint(pos.bp)
    app.register_blueprint(inventory.bp)
    app.register_blueprint(expenses.bp)
    app.register_blueprint(reports.bp)

    from app.seed import seed
    with app.app_context():
        db.create_all()
        seed()

    return app
