addEventListener('DOMContentLoaded', () => {
  // Normalize string for foolproof category/text matching
  function normalizeText(str) {
    return (str || '')
      .toString()
      .toLowerCase()
      .replace(/&amp;/g, '&')
      .replace(/[^a-z0-9]/g, '');
  }

  // Search & Category Filter
  const searchInput = document.querySelector('#search');
  const catChips = document.querySelectorAll('.cat-chip');
  let selectedCategory = 'all';

  function filterMenuItems() {
    const q = (searchInput?.value || '').toLowerCase().trim();
    const cleanSelectedCat = normalizeText(selectedCategory);

    document.querySelectorAll('.item').forEach(item => {
      const name = (item.dataset.name || '').toLowerCase();
      const cat = normalizeText(item.dataset.category || '');

      const matchesSearch = !q || name.includes(q);
      const matchesCat =
        selectedCategory === 'all' ||
        cat.includes(cleanSelectedCat) ||
        cleanSelectedCat.includes(cat);

      if (matchesSearch && matchesCat) {
        item.classList.remove('is-hidden');
      } else {
        item.classList.add('is-hidden');
      }
    });
  }

  if (searchInput) {
    searchInput.addEventListener('input', filterMenuItems);
  }

  catChips.forEach(chip => {
    chip.addEventListener('click', () => {
      catChips.forEach(c => c.classList.remove('active'));
      chip.classList.add('active');
      selectedCategory = chip.dataset.cat || 'all';
      filterMenuItems();
    });
  });

  // Cart & POS Logic
  const cart = {};
  const cartEl = document.querySelector('#cart');
  const hiddenEl = document.querySelector('#hidden');
  const totalEl = document.querySelector('#total');
  const itemsCountEl = document.querySelector('#items-count');
  const btnClear = document.querySelector('#btn-clear');
  const btnPrintCart = document.querySelector('#btn-print-cart');

  document.querySelectorAll('.item').forEach(btn => {
    btn.addEventListener('click', () => {
      const id = btn.dataset.id;
      if (!cart[id]) {
        cart[id] = {
          id: id,
          name: btn.dataset.label,
          price: parseFloat(btn.dataset.price),
          qty: 0
        };
      }
      cart[id].qty++;
      renderCart();
    });
  });

  function renderCart() {
    if (!cartEl) return;
    cartEl.innerHTML = '';
    if (hiddenEl) hiddenEl.innerHTML = '';

    let total = 0;
    let totalItems = 0;
    const items = Object.values(cart).filter(item => item.qty > 0);

    if (items.length === 0) {
      cartEl.innerHTML = '<p class="empty-cart">🛒 No items added yet.<br><small style="margin-top:6px;display:block;color:#889990;">Click on menu items on the left to start billing.</small></p>';
      if (btnClear) btnClear.style.display = 'none';
      if (totalEl) totalEl.textContent = '₹0';
      if (itemsCountEl) itemsCountEl.textContent = '0 items';
      return;
    }

    if (btnClear) btnClear.style.display = 'inline-block';

    items.forEach(item => {
      const itemTotal = item.qty * item.price;
      total += itemTotal;
      totalItems += item.qty;

      const row = document.createElement('div');
      row.className = 'row cart-row';
      row.innerHTML = `
        <div class="cart-item-info">
          <span class="cart-item-name">${item.name}</span>
          <span class="cart-item-rate">₹${item.price.toFixed(0)} each</span>
        </div>
        <div class="cart-item-controls">
          <button type="button" class="btn-qty btn-minus" data-id="${item.id}" title="Decrease">−</button>
          <span class="qty-badge">${item.qty}</span>
          <button type="button" class="btn-qty btn-plus" data-id="${item.id}" title="Increase">+</button>
          <b class="cart-item-total">₹${itemTotal.toFixed(0)}</b>
        </div>
      `;
      cartEl.appendChild(row);

      if (hiddenEl) {
        hiddenEl.innerHTML += `
          <input type="hidden" name="item_id" value="${item.id}">
          <input type="hidden" name="qty" value="${item.qty}">
        `;
      }
    });

    if (totalEl) totalEl.textContent = `₹${total.toFixed(0)}`;
    if (itemsCountEl) itemsCountEl.textContent = `${totalItems} item${totalItems > 1 ? 's' : ''}`;

    // Attach +/- listeners
    cartEl.querySelectorAll('.btn-plus').forEach(b => {
      b.onclick = () => {
        const id = b.dataset.id;
        if (cart[id]) {
          cart[id].qty++;
          renderCart();
        }
      };
    });

    cartEl.querySelectorAll('.btn-minus').forEach(b => {
      b.onclick = () => {
        const id = b.dataset.id;
        if (cart[id]) {
          cart[id].qty--;
          if (cart[id].qty <= 0) {
            delete cart[id];
          }
          renderCart();
        }
      };
    });
  }

  if (btnClear) {
    btnClear.addEventListener('click', () => {
      for (const k in cart) delete cart[k];
      renderCart();
    });
  }

  // Quick Print Current Bill
  if (btnPrintCart) {
    btnPrintCart.addEventListener('click', () => {
      const items = Object.values(cart).filter(item => item.qty > 0);
      if (items.length === 0) {
        alert('Please add items to the bill before printing!');
        return;
      }

      const orderType = document.querySelector('#order-type')?.value || 'Takeaway';
      const paymentMode = document.querySelector('#payment-mode')?.value || 'Cash';
      let total = 0;
      const now = new Date();
      const dateStr = now.toLocaleDateString('en-GB');
      const timeStr = now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: true });

      let rowsHtml = '';
      items.forEach(it => {
        const itemTotal = it.qty * it.price;
        total += itemTotal;
        rowsHtml += `
          <tr>
            <td>${it.name}</td>
            <td style="text-align:center;">${it.qty}</td>
            <td style="text-align:right;">₹${it.price.toFixed(0)}</td>
            <td style="text-align:right;">₹${itemTotal.toFixed(0)}</td>
          </tr>
        `;
      });

      const receiptHtml = `
        <!doctype html>
        <html>
        <head>
          <meta charset="utf-8">
          <title>Receipt Preview</title>
          <style>
            * { box-sizing: border-box; margin: 0; padding: 0; font-family: 'Courier New', monospace; }
            body { padding: 15px; font-size: 13px; color: #000; }
            .text-center { text-align: center; }
            .divider { border-top: 1px dashed #333; margin: 8px 0; }
            .double-divider { border-top: 2px solid #000; margin: 8px 0; }
            .title { font-size: 17px; font-weight: bold; }
            .subtitle { font-size: 11px; }
            .meta { display: flex; justify-content: space-between; font-size: 11px; margin: 2px 0; }
            table { width: 100%; border-collapse: collapse; margin: 8px 0; font-size: 12px; }
            th { border-bottom: 1px dashed #333; padding-bottom: 4px; text-align: left; }
            td { padding: 3px 0; }
            .total { display: flex; justify-content: space-between; font-size: 15px; font-weight: bold; margin: 6px 0; }
            .footer { text-align: center; font-size: 11px; margin-top: 10px; }
            @media print { body { padding: 0; } }
          </style>
        </head>
        <body>
          <div class="text-center">
            <div class="title">☕ Graduate Tea</div>
            <div class="subtitle">Tea Hotel Management</div>
            <div class="subtitle">Quick Bill Receipt</div>
          </div>
          <div class="double-divider"></div>
          <div class="meta"><span><b>Date:</b> ${dateStr}</span><span><b>Time:</b> ${timeStr}</span></div>
          <div class="meta"><span><b>Type:</b> ${orderType}</span><span><b>Payment:</b> ${paymentMode}</span></div>
          <div class="divider"></div>
          <table>
            <thead><tr><th>Item</th><th style="text-align:center;">Qty</th><th style="text-align:right;">Rate</th><th style="text-align:right;">Total</th></tr></thead>
            <tbody>${rowsHtml}</tbody>
          </table>
          <div class="divider"></div>
          <div class="total"><span>TOTAL:</span><span>₹${total.toFixed(0)}</span></div>
          <div class="double-divider"></div>
          <div class="footer">*** Thank You! Visit Again ***</div>
        </body>
        </html>
      `;

      const printWin = window.open('', '_blank', 'width=380,height=550');
      if (printWin) {
        printWin.document.open();
        printWin.document.write(receiptHtml);
        printWin.document.close();
        printWin.focus();
        setTimeout(() => {
          printWin.print();
        }, 250);
      } else {
        alert('Popup blocked. Please allow popups for this site to print receipts.');
      }
    });
  }

  // Dashboard Chart
  const chartCanvas = document.querySelector('#chart');
  const chartData = window.chartData;
  if (chartCanvas && chartData && chartData.labels && chartData.labels.length > 0) {
    const ctx = chartCanvas.getContext('2d');
    const maxVal = Math.max(...chartData.values, 1);
    chartCanvas.height = Math.max(180, chartData.labels.length * 36 + 30);

    chartData.labels.forEach((name, i) => {
      const y = 20 + i * 36;
      const barWidth = (chartData.values[i] / maxVal) * 230;

      // Background Bar
      ctx.fillStyle = '#eaf2ec';
      ctx.beginPath();
      ctx.roundRect ? ctx.roundRect(130, y, 230, 20, 4) : ctx.fillRect(130, y, 230, 20);
      ctx.fill();

      // Filled Progress Bar
      ctx.fillStyle = '#0f8a52';
      ctx.beginPath();
      ctx.roundRect ? ctx.roundRect(130, y, barWidth, 20, 4) : ctx.fillRect(130, y, barWidth, 20);
      ctx.fill();

      // Item Name
      ctx.fillStyle = '#1e3328';
      ctx.font = 'bold 12px Segoe UI, sans-serif';
      const truncated = name.length > 15 ? name.substring(0, 14) + '…' : name;
      ctx.fillText(truncated, 5, y + 14);

      // Sold Count
      ctx.fillStyle = '#0f8a52';
      ctx.font = 'bold 12px Segoe UI, sans-serif';
      ctx.fillText(chartData.values[i] + ' sold', 370, y + 14);
    });
  }
});
