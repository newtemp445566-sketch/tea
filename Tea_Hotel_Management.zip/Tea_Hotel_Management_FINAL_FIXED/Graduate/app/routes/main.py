from flask import Blueprint, render_template, session, redirect, url_for
from sqlalchemy import func
from app import db
from app.models import Sale, Expense, MenuItem, SaleItem

bp = Blueprint('main', __name__)


@bp.route('/')
def index():
    if session.get('user_id'):
        return redirect(url_for('main.dashboard'))
    return redirect(url_for('auth.login'))


@bp.route('/dashboard')
def dashboard():
    if not session.get('user_id'):
        return redirect(url_for('auth.login'))

    revenue = db.session.query(func.coalesce(func.sum(Sale.total), 0.0)).scalar() or 0.0
    expenses = db.session.query(func.coalesce(func.sum(Expense.amount), 0.0)).scalar() or 0.0
    orders_count = Sale.query.count()
    low_stock_count = MenuItem.query.filter(MenuItem.stock_qty <= MenuItem.low_stock).count()
    profit = revenue - expenses

    # Top selling items
    top_items = (
        db.session.query(MenuItem.name, func.sum(SaleItem.quantity))
        .join(SaleItem, MenuItem.id == SaleItem.menu_item_id)
        .group_by(MenuItem.id)
        .order_by(func.sum(SaleItem.quantity).desc())
        .limit(6)
        .all()
    )

    chart_labels = [row[0] for row in top_items]
    chart_values = [int(row[1]) for row in top_items]
    recent_sales = Sale.query.order_by(Sale.created_at.desc()).limit(6).all()

    return render_template(
        'dashboard.html',
        revenue=revenue,
        expenses=expenses,
        profit=profit,
        orders=orders_count,
        low=low_stock_count,
        labels=chart_labels,
        values=chart_values,
        recent=recent_sales
    )
