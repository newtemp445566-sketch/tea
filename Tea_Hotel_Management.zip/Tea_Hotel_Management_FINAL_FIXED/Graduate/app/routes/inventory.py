from flask import Blueprint, render_template, request, redirect, url_for, session, flash
from app import db
from app.models import MenuItem, Ingredient

bp = Blueprint('inventory', __name__, url_prefix='/inventory')


@bp.route('')
def index():
    if not session.get('user_id'):
        return redirect(url_for('auth.login'))

    menu_items = MenuItem.query.all()
    ingredients = Ingredient.query.all()
    return render_template('inventory.html', items=menu_items, ingredients=ingredients)


@bp.route('/add', methods=['POST'])
def add():
    if not session.get('user_id'):
        return redirect(url_for('auth.login'))

    name = request.form.get('name', '').strip()
    category = request.form.get('category', '').strip()

    try:
        price = float(request.form.get('price', 0))
        cost = float(request.form.get('cost', 0))
        stock_qty = float(request.form.get('stock', 0))
    except ValueError:
        flash('Invalid numeric values entered', 'error')
        return redirect(url_for('inventory.index'))

    if not name or not category:
        flash('Item name and category are required', 'error')
        return redirect(url_for('inventory.index'))

    item = MenuItem(
        name=name,
        category=category,
        price=price,
        cost=cost,
        stock_qty=stock_qty,
        low_stock=10.0,
        active=True
    )
    db.session.add(item)
    db.session.commit()

    flash(f'Menu item "{name}" added successfully', 'success')
    return redirect(url_for('inventory.index'))
