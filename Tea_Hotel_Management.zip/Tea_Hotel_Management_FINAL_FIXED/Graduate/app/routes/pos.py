from datetime import datetime
from flask import Blueprint, render_template, request, redirect, url_for, session, flash
from app import db
from app.models import MenuItem, Sale, SaleItem

bp = Blueprint('pos', __name__, url_prefix='/pos')


@bp.route('')
def index():
    if not session.get('user_id'):
        return redirect(url_for('auth.login'))

    menu_items = MenuItem.query.filter_by(active=True).all()
    return render_template('pos.html', items=menu_items)


@bp.route('/save', methods=['POST'])
def save():
    if not session.get('user_id'):
        return redirect(url_for('auth.login'))

    action = request.form.get('action', 'save')
    payment_mode = request.form.get('payment', 'Cash')
    order_type = request.form.get('type', 'Takeaway')

    item_ids = request.form.getlist('item_id')
    quantities = request.form.getlist('qty')

    if not item_ids or not quantities:
        flash('Please select at least one item before saving', 'error')
        return redirect(url_for('pos.index'))

    sale = Sale(
        created_at=datetime.utcnow(),
        payment_mode=payment_mode,
        order_type=order_type
    )
    db.session.add(sale)
    db.session.flush()

    total_amount = 0.0
    has_items = False

    for item_id_str, qty_str in zip(item_ids, quantities):
        try:
            qty = float(qty_str)
            item_id = int(item_id_str)
        except ValueError:
            continue

        if qty <= 0:
            continue

        menu_item = db.session.get(MenuItem, item_id)
        if not menu_item:
            continue

        sale_item = SaleItem(
            sale_id=sale.id,
            menu_item_id=menu_item.id,
            quantity=qty,
            unit_price=menu_item.price
        )
        db.session.add(sale_item)

        # Update remaining stock
        menu_item.stock_qty = max(0.0, menu_item.stock_qty - qty)
        total_amount += menu_item.price * qty
        has_items = True

    if not has_items:
        db.session.rollback()
        flash('Please add at least one valid item', 'error')
        return redirect(url_for('pos.index'))

    sale.total = total_amount
    db.session.commit()

    flash(f'Bill #{sale.id} saved successfully — ₹{total_amount:.0f}', 'success')

    if action == 'save_print':
        return redirect(url_for('pos.receipt', sale_id=sale.id, auto_print=1))

    return redirect(url_for('pos.index'))


@bp.route('/receipt/<int:sale_id>')
def receipt(sale_id):
    if not session.get('user_id'):
        return redirect(url_for('auth.login'))

    sale = Sale.query.get_or_404(sale_id)
    return render_template('receipt.html', sale=sale)
