from datetime import date
from flask import Blueprint, render_template, request, redirect, url_for, session, flash
from app import db
from app.models import Expense

bp = Blueprint('expenses', __name__, url_prefix='/expenses')


@bp.route('')
def index():
    if not session.get('user_id'):
        return redirect(url_for('auth.login'))

    expense_list = Expense.query.order_by(Expense.expense_date.desc()).all()
    total_expenses = sum(x.amount for x in expense_list)

    return render_template('expenses.html', expenses=expense_list, total=total_expenses)


@bp.route('/add', methods=['POST'])
def add():
    if not session.get('user_id'):
        return redirect(url_for('auth.login'))

    title = request.form.get('title', '').strip()
    category = request.form.get('category', '').strip()
    date_str = request.form.get('date', '')

    try:
        amount = float(request.form.get('amount', 0))
    except ValueError:
        flash('Invalid expense amount', 'error')
        return redirect(url_for('expenses.index'))

    try:
        expense_date = date.fromisoformat(date_str) if date_str else date.today()
    except ValueError:
        expense_date = date.today()

    if not title or not category:
        flash('Expense title and category are required', 'error')
        return redirect(url_for('expenses.index'))

    expense = Expense(
        title=title,
        category=category,
        amount=amount,
        expense_date=expense_date
    )
    db.session.add(expense)
    db.session.commit()

    flash(f'Expense "{title}" of ₹{amount:.0f} saved successfully', 'success')
    return redirect(url_for('expenses.index'))
