import csv
import io
from flask import Blueprint, render_template, session, redirect, url_for, Response
from app.models import Sale

bp = Blueprint('reports', __name__, url_prefix='/reports')


@bp.route('')
def index():
    if not session.get('user_id'):
        return redirect(url_for('auth.login'))

    sales_history = Sale.query.order_by(Sale.created_at.desc()).all()
    return render_template('reports.html', sales=sales_history)


@bp.route('/csv')
def csvfile():
    if not session.get('user_id'):
        return redirect(url_for('auth.login'))

    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(['Bill ID', 'Date & Time', 'Order Type', 'Payment Mode', 'Total Amount'])

    for sale in Sale.query.order_by(Sale.created_at.desc()).all():
        date_str = sale.created_at.strftime('%Y-%m-%d %H:%M:%S')
        writer.writerow([sale.id, date_str, sale.order_type, sale.payment_mode, f"{sale.total:.2f}"])

    return Response(
        output.getvalue(),
        mimetype='text/csv',
        headers={'Content-Disposition': 'attachment; filename=chaitrack_sales_report.csv'}
    )
